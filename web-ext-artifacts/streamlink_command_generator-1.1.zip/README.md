# Streamlink Command Generator

This is a tool to record youtube video or live stream

First, you need to have streamlink installed, but if you haven't you can go to https://github.com/streamlink/windows-builds/releases

For using it all you need to do is just click Streamlink Command Generator add-on icon on your dashboard, click copy, and paste it on command prompt (cmd)

You can find the recorded file on `D:\Downloads Stream`
