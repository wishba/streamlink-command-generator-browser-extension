# Streamlink Command Generator Browser extension

This is a tool to record youtube video or live stream

You can use this on chrome or firefox

Download `Streamlink Command Generator` on [releases page](https://github.com/wishba/streamlink-command-generator-browser-extension/releases) and install it on your browser

Also you need to have streamlink installed but if you haven't you can go to https://github.com/streamlink/windows-builds/releases

For using it all you need to do is just click Streamlink Command Generator icon on your dashboard, click copy, and paste the command on command prompt (cmd)

You can find the recorded file on `D:\Downloads Stream`
